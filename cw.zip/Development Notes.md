# Hi.

Notes
-----

1) Make the A matrix. Banded with -2 on the diagonal and 1 on the off-diagonal.